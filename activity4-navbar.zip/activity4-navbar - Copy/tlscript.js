let currentLight = "red";
let running = false;
let interval;

function updateLights(color) {
  document.getElementById("red").style.backgroundColor = color === "red" ? "red" : "#555";
  document.getElementById("yellow").style.backgroundColor = color === "yellow" ? "yellow" : "#555";
  document.getElementById("green").style.backgroundColor = color === "green" ? "green" : "#555";
}

function changeLight() {
  if (currentLight === "red") {
    updateLights("green");
    currentLight = "green";
  } else if (currentLight === "green") {
    updateLights("yellow");
    currentLight = "yellow";
  } else if (currentLight === "yellow") {
    updateLights("red");
    currentLight = "red";
  }
}

function startTrafficLight() {
  if (!running) {
    running = true;
    document.getElementById("startbtn").disabled = true;
    document.getElementById("stopbtn").disabled = false;
    updateLights("green");
    interval = setInterval(changeLight, 3000);
  }
}

function stopTrafficLight() {
  clearInterval(interval);
  running = false;
  document.getElementById("startbtn").disabled = false;
  document.getElementById("stopbtn").disabled = true;
  updateLights("");
}
